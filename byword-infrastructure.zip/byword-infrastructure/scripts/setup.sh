#!/bin/bash
set -e
ENV=${1:-development}
PROJECT=${2:-}
DOMAIN=${3:-}

if [[ -z "$PROJECT" || -z "$DOMAIN" ]]; then
  echo "Usage: ./scripts/setup.sh <env> <project-id> <domain>"
  exit 1
fi

cat > terraform/terraform.tfvars << EOV
project_id = "$PROJECT"
environment = "$ENV"
region = "us-central1"
EOV

echo "✅ terraform.tfvars created for $ENV"
