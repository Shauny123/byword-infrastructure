# Byword Infrastructure

Kubernetes migration pipeline for the Byword FastAPI system.

## Quick Start

```bash
./scripts/setup.sh production my-project-id byword.com
cd terraform
terraform init
terraform apply
```
